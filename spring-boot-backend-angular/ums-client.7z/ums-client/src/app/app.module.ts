import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { LOCALE_ID, NgModule } from '@angular/core';

import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { ClientComponent } from './client/client.component';
import { ClientService } from './client/client.service';
import { DetailComponent } from './client/detail/detail.component';
import { FormComponent } from './client/form/form.component';
import { DirectiveComponent } from './directive/directive.component';
import { FooterComponent } from './footer/footer.component';
import { HeaderComponent } from './header/header.component';
import { DetailInvoiceComponent } from './invoice/detail-invoice.component';
import { InvoiceComponent } from './invoice/invoice.component';
import { AuthGuard } from './user/guard/auth.guard';
import { RoleGuard } from './user/guard/role.guard';
import { AuthInterceptor } from './user/interceptor/auth.interceptor';
import { TokenInterceptor } from './user/interceptor/token.interceptor';
import { LoginComponent } from './user/login.component';
import { PaginationComponent } from './pagination/pagination.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
 

import { MatNativeDateModule } from '@angular/material/core';

const routes: Routes = [
  { path: '', redirectTo: '/client', pathMatch: 'full' },
  { path: 'directive', component: DirectiveComponent },
  { path: 'client', component: ClientComponent },
  { path: 'client/page/:page', component: ClientComponent },
  { path: 'client/form', component: FormComponent, canActivate: [AuthGuard, RoleGuard], data: { role: 'ROLE_ADMIN' } },
  { path: 'client/form/:id', component: FormComponent, canActivate: [AuthGuard, RoleGuard], data: { role: 'ROLE_ADMIN' } },
  { path: 'login', component: LoginComponent },
  { path: 'invoice/:id', component: DetailInvoiceComponent, canActivate: [AuthGuard, RoleGuard], data: { role: 'ROLE_USER' } },
  { path: 'invoice/form/:clientId', component: InvoiceComponent, canActivate: [AuthGuard, RoleGuard], data: { role: 'ROLE_ADMIN' } }
];

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    DirectiveComponent,
    ClientComponent,
    FormComponent,
    InvoiceComponent,
    DetailComponent,
    LoginComponent,
    PaginationComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routes),
    BrowserAnimationsModule, MatDatepickerModule,
    MatAutocompleteModule, MatInputModule, MatFormFieldModule, MatNativeDateModule,
    MatDatepickerModule, MatAutocompleteModule, MatInputModule, MatFormFieldModule
  ],
  providers: [ClientService,
    MatDatepickerModule,
    MatNativeDateModule,
    { provide: LOCALE_ID, useValue: 'en-US' },
    { provide: HTTP_INTERCEPTORS, useClass: TokenInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
