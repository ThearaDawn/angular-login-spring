import { Invoice } from '../invoice/model/invoice';
import { Region } from './region';


export class  Client {
  id: number;
  firstName: string;
  lastName: string;
  createAt: string;
  email: string;
  photo: string;
  region: Region;
  invoices: Array<Invoice> = [];
}
