import { HttpEventType } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import swal from 'sweetalert2';
import { InvoiceService } from '../../invoice/invoice.service';
import { Invoice } from '../../invoice/model/invoice';
import { Client } from '../client';
import { ClientService } from '../client.service';
import { ModalService } from './modal.service';




@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})

export class DetailComponent implements OnInit {


  @Input() client: Client;

  titulo: string = "Detalle del cliente";
  private selectPhoto: File;
  progreso: number = 0;

  constructor(private clientService: ClientService,
    private invoiceService: InvoiceService,
    public modalService: ModalService) { }

  ngOnInit() { }

  seleccionarFoto(event) {
    this.selectPhoto = event.target.files[0];
    this.progreso = 0;
    console.log(this.selectPhoto);
    if (this.selectPhoto.type.indexOf('image') < 0) {
      swal('Error while select image: ', 'The file must be of type image', 'error');
      this.selectPhoto = null;
    }
  }

  uploadPhoto() {

    if (!this.selectPhoto) {
      swal('Error Upload: ', 'You must select a photo ', 'error');
    } else {
      this.clientService.subirFoto(this.selectPhoto, this.client.id)
        .subscribe(event => {
          if (event.type === HttpEventType.UploadProgress) {
            this.progreso = Math.round((event.loaded / event.total) * 100);
          } else if (event.type === HttpEventType.Response) {
            let response: any = event.body;
            this.client = response.cliente as Client;

            this.modalService.notificarUpload.emit(this.client);
            swal('The photo has been fully uploaded!', response.mensaje, 'success');
          }
        });
    }
  }

  createModal() {
    this.modalService.createModal();
    this.selectPhoto = null;
    this.progreso = 0;
  }

  delete(invoice: Invoice): void {
    swal({
      title: 'Are you sure?',
      text: `You sure want to delete the invoice ${invoice.description}?`,
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, remove!',
      cancelButtonText: 'No, cancel!',
      confirmButtonClass: 'btn btn-success',
      cancelButtonClass: 'btn btn-danger',
      buttonsStyling: false,
      reverseButtons: true
    }).then((result) => {
      if (result.value) {

        this.invoiceService.delete(invoice.id).subscribe(
          () => {
            this.client.invoices = this.client.invoices.filter(f => f !== invoice)
            swal(
              'Invoice deleted!',
              `Invoice ${invoice.description} successfully removed.`,
              'success'
            )
          }
        )

      }
    });
  }

}
