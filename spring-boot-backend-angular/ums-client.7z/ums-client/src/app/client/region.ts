export class Region {
    id: number;
    name: string;
}
