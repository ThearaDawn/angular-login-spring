import { Component, OnInit } from '@angular/core';

import { Client } from '../client';
import { Region } from '../region';
import { ClientService } from '../client.service';
import { Router, ActivatedRoute } from '@angular/router';
import swal from 'sweetalert2';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {

  
  public client: Client = new Client();
  regions: Region[];
  title: string = "Create Client";

  errors: string[];

  constructor(private clientService: ClientService,
    private router: Router,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.activatedRoute.paramMap.subscribe(params => {
      let id = +params.get('id');
      if (id) {
        this.clientService.getClientById(id).subscribe((client) => this.client = client);
      }
    });

    this.clientService.getRegiones().subscribe(regions => this.regions = regions);
  }

  create(): void {
    console.log(this.client);
    this.clientService.create(this.client)
      .subscribe(
        client => {
          this.router.navigate(['/client']);
          swal('New client', `The client ${client.firstName} has been created successfully`, 'success');
        },
        err => {
          this.errors = err.error.errors as string[];
          console.error('Error code from the backend: ' + err.status);
          console.error(err.error.errors);
        }
      );
  }

  update(): void {
    console.log(this.client);
    this.client.invoices = null;
    this.clientService.update(this.client)
      .subscribe(
        json => {
          this.router.navigate(['/client']);
          swal('Client updated', `${json.message}: ${json.client.firstName}`, 'success');
        },
        err => {
          this.errors = err.error.errors as string[];
          console.error('Error code from the backend: ' + err.status);
          console.error(err.error.errors);
        }
      )
  }

  compararRegion(o1: Region, o2: Region): boolean {
    if (o1 === undefined && o2 === undefined) {
      return true;
    }

    return o1 === null || o2 === null || o1 === undefined || o2 === undefined ? false : o1.id === o2.id;
  }


}
