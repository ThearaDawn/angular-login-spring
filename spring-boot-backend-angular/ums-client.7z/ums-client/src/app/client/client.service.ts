import { Injectable } from '@angular/core';
import { Client } from './client';
import { Observable, throwError } from 'rxjs';

import { Router } from '@angular/router';
import { HttpClient, HttpEvent, HttpRequest } from '@angular/common/http';
import { map, catchError, tap } from 'rxjs/operators';
import { Region } from './region';


import { URL_BACKEND } from '../config/config';

@Injectable({
  providedIn: 'root'
})

export class ClientService {

  private urlEndPoint = URL_BACKEND + 'api/clients'

  constructor(private http: HttpClient, private router: Router) { }

  /*  getClients(): Observable<Client[]> {
     //return of(CLIENTS);
     return this.http.get<Client[]>(this.urlEndPoint).pipe(
       map( response => response as Client[])
     );
 
   } */




  getRegiones(): Observable<Region[]> {
    return this.http.get<Region[]>(this.urlEndPoint + '/regions');
  }

  getClients(page: number): Observable<any> {
    return this.http.get(this.urlEndPoint + '/page/' + page).pipe(
      tap((response: any) => {
        console.log('ClientService: tap 1');
        (response.content as Client[]).forEach(client => console.log(client.firstName));
      }),
      map((response: any) => {
        (response.content as Client[]).map(client => {
          client.firstName = client.firstName.toUpperCase();
          return client;
        });
        return response;
      }),
      tap(response => {
        console.log('ClientService: tap 2');
        (response.content as Client[]).forEach(client => console.log(client.firstName));
      }));
  }

  create(client: Client): Observable<Client> {
    return this.http.post(this.urlEndPoint, client)
      .pipe(
        map((response: any) => response.client as Client),
        catchError(e => {
          if (e.status == 400) {
            return throwError(e);
          }
          if (e.error.message) {
            console.error(e.error.message);
          }
          return throwError(e);
        }));
  }

  getClientById(id): Observable<Client> {
    return this.http.get<Client>(`${this.urlEndPoint}/${id}`).pipe(
      catchError(e => {
        if (e.status != 401 && e.error.message) {
          this.router.navigate(['/client']);
          console.error(e.error.message);
        }

        return throwError(e);
      }));
  }

  update(cliente: Client): Observable<any> {
    return this.http.put<any>(`${this.urlEndPoint}/${cliente.id}`, cliente).pipe(
      catchError(e => {
        if (e.status == 400) {
          return throwError(e);
        }
        if (e.error.message) {
          console.error(e.error.message);
        }
        return throwError(e);
      }));
  }

  delete(id: number): Observable<Client> {
    return this.http.delete<Client>(`${this.urlEndPoint}/${id}`).pipe(
      catchError(e => {
        if (e.error.message) {
          console.error(e.error.message);
        }
        return throwError(e);
      }));
  }

  subirFoto(archive: File, id): Observable<HttpEvent<{}>> {
    let formData = new FormData();
    formData.append("archive", archive);
    formData.append("id", id);

    const req = new HttpRequest('POST', `${this.urlEndPoint}/upload`, formData, {
      reportProgress: true
    });

    return this.http.request(req);
  }

}
