import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { flatMap, map } from 'rxjs/operators';
import swal from 'sweetalert2';
import { ClientService } from '../client/client.service';
import { InvoiceService } from './invoice.service';
import { Bill } from './model/bill';
import { Invoice } from './model/invoice';
import { Product } from './model/product';






@Component({
  selector: 'app-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.css']
})
export class InvoiceComponent implements OnInit {

  title = 'New Invoice';
  invoice = new Invoice();

  autocompleteControl = new FormControl();

  filterProduct: Observable<Product[]>;

  constructor(private clientService: ClientService,
    private invoiceService: InvoiceService,
    private router: Router,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.activatedRoute.paramMap.subscribe(params => {
      let clientId = +params.get('clientId');
      this.clientService.getClientById(clientId).subscribe(client => this.invoice.client = client);
    });

    this.filterProduct = this.autocompleteControl.valueChanges
      .pipe(
        map(value => typeof value === 'string' ? value : value.name),
        flatMap(value => value ? this._filter(value) : [])
      );
  }

  private _filter(value: string): Observable<Product[]> {
    const filterValue = value.toLowerCase();

    return this.invoiceService.filterProduct(filterValue);
  }

  productName(product?: Product): string | undefined {
    return product ? product.name : undefined;
  }

  selectProduct(event: MatAutocompleteSelectedEvent): void {
    let product = event.option.value as Product;
    console.log(product);

    if (this.existeItem(product.id)) {
      this.increasesQuantity(product.id);
    } else {
      let bill = new Bill();
      bill.product = product;
      this.invoice.items.push(bill);
    }

    this.autocompleteControl.setValue('');
    event.option.focus();
    event.option.deselect();

  }

  updateQuantity(id: number, event: any): void {
    let quantity: number = event.target.value as number;

    if (quantity == 0) {
      return this.deleteItemInvoice(id);
    }

    this.invoice.items = this.invoice.items.map((item: Bill) => {
      if (id === item.product.id) {
        item.quantity = quantity;
      }
      return item;
    });
  }

  existeItem(id: number): boolean {
    let exist = false;
    this.invoice.items.forEach((item: Bill) => {
      if (id === item.product.id) {
        exist = true;
      }
    });
    return exist;
  }

  increasesQuantity(id: number): void {
    this.invoice.items = this.invoice.items.map((item: Bill) => {
      if (id === item.product.id) {
        ++item.quantity;
      }
      return item;
    });
  }

  deleteItemInvoice(id: number): void {
    this.invoice.items = this.invoice.items.filter((item: Bill) => id !== item.product.id);
  }

  create(invoiceForm): void {
    console.log(this.invoice);
    if (this.invoice.items.length == 0) {
      this.autocompleteControl.setErrors({ 'invalid': true });
    }

    if (invoiceForm.form.valid && this.invoice.items.length > 0) {
      this.invoiceService.create(this.invoice).subscribe(invoice => {
        swal(this.title, `Invoice ${invoice.description}successfully created!`, 'success');
        this.router.navigate(['/invoice', invoice.id]);
      });
    }
  }


}
