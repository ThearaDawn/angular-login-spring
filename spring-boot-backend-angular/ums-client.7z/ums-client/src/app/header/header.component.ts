import { Component, OnInit } from '@angular/core';

import { AuthService } from '../user/auth.service';
import { Router } from '@angular/router';
import swal from 'sweetalert2';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  title = "App Angular";

  constructor(public authService: AuthService, private router: Router) { }

  logout(): void {
    let username = this.authService.user.username;
    this.authService.logout();
    swal('Logout', `Hi ${username}, you have successfully logged out!`, 'success');
    this.router.navigate(['/login']);
  }

  ngOnInit(): void {
  }

}
