import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import swal from 'sweetalert2';
import { AuthService } from './auth.service';
import { User } from './user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html'
})
export class LoginComponent implements OnInit {

  title: string = 'Sign In!';
  user: User;

  constructor(private authService: AuthService, private router: Router) {
    this.user = new User();
  }

  ngOnInit() {
    if (this.authService.isAuthenticated()) {
      swal('Login', `Hi ${this.authService.user.username} you are already authenticated!`, 'info');
      this.router.navigate(['/client']);
    }
  }

  login(): void {
    console.log(this.user);
    if (this.user.username == null || this.user.password == null) {
      swal('Error Login', 'Incorrect username or password!', 'error');
      return;
    }

    this.authService.login(this.user).subscribe(response => {
      console.log(response);

      this.authService.saveUser(response.access_token);
      this.authService.saveToken(response.access_token);
      let user = this.authService.user;
      this.router.navigate(['/client']);
      swal('Login', `Hi ${user.username}, you have successfully logged in!`, 'success');
    }, err => {
      if (err.status == 400) {
        swal('Error Login', 'Incorrect username or password!', 'error');
      }
    }
    );
  }

}
