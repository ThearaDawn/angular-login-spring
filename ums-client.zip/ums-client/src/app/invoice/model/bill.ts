import { Product } from './product';

export class Bill {
  product: Product;
  quantity: number = 1;
  sumProduct: number;

  public calculateProduct(): number {
    return this.quantity * this.product.price;
  }
}
