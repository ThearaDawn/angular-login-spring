import { Bill } from './bill';
import { Client } from '../../client/client';

export class Invoice {
    id: number;
    description: string;
    observation: string;
    items: Array<Bill> = [];
    client: Client;
    total: number;
    createAt: string;

    calculateGranTotal(): number {
        this.total = 0;
        this.items.forEach((item: Bill) => {
            this.total += item.calculateProduct();
        });
        return this.total;
    }
}
