import { Injectable } from '@angular/core';


import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Invoice } from '../invoice/model/invoice';
import { Product } from '../invoice/model/product';

import { URL_BACKEND } from '../config/config';


@Injectable({
  providedIn: 'root'
})
export class InvoiceService {

  private urlEndPoint: string = URL_BACKEND + '/api/invoice';

  constructor(private http: HttpClient) { }

  getInvoiceById(id: number): Observable<Invoice> {
    return this.http.get<Invoice>(`${this.urlEndPoint}/${id}`);
  }

  delete(id: number): Observable<void> {
    return this.http.delete<void>(`${this.urlEndPoint}/${id}`);
  }

  filterProduct(name: string): Observable<Product[]> {
    return this.http.get<Product[]>(`${this.urlEndPoint}/filter/product/${name}`);
  }

  create(invoice: Invoice): Observable<Invoice> {
    return this.http.post<Invoice>(this.urlEndPoint, invoice);
  }
}
