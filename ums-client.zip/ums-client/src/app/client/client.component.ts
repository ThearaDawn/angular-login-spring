import { Component, OnInit } from '@angular/core';
import { Client } from './client';
import { ClientService } from './client.service';

import swal from 'sweetalert2';
import { tap } from 'rxjs/operators';
import { ActivatedRoute } from '@angular/router';

import { URL_BACKEND } from '../config/config';
import { ModalService } from './detail/modal.service';


import { AuthService } from '../user/auth.service';

@Component({
  selector: 'app-client',
  templateUrl: './client.component.html',
  styleUrls: ['./client.component.css']
})
export class ClientComponent implements OnInit {


  clients: Client[];
  pagination: any;
  clientSelected: Client;
  urlBackend: string = URL_BACKEND;


  constructor(private clientService: ClientService,
    public modalService: ModalService,
    public authService: AuthService,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.activatedRoute.paramMap.subscribe(params => {
      let page: number = +params.get('page');

      if (!page) {
        page = 0;
      }

      this.clientService.getClients(page)
        .pipe(
          tap(response => {
            console.log('ClientComponent: tap 3');
            (response.content as Client[]).forEach(client => console.log(client.firstName));
          })
        ).subscribe(response => {
          this.clients = response.content as Client[];
          this.pagination = response;
        });
    });

    this.modalService.notificarUpload.subscribe(client => {
      this.clients = this.clients.map(clientOriginal => {
        if (client.id == clientOriginal.id) {
          clientOriginal.photo = client.photo;
        }
        return clientOriginal;
      })
    })
  }

  delete(client: Client): void {
    swal({
      title: 'Are you sure?',
      text: `Are you sure you want to delete the client ${client.firstName} ${client.lastName}?`,
      type: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, remove!',
      cancelButtonText: 'No, cancel!',
      confirmButtonClass: 'btn btn-success',
      cancelButtonClass: 'btn btn-danger',
      buttonsStyling: false,
      reverseButtons: true
    }).then((result) => {
      if (result.value) {

        this.clientService.delete(client.id).subscribe(
          () => {
            this.clients = this.clients.filter(cli => cli !== client)
            swal(
              'Client removed!',
              `Client ${client.firstName} removed successfully.`,
              'success'
            )
          }
        )

      }
    });
  }

  openModal(client: Client) {
    this.clientSelected = client;
    this.modalService.openModal();
  }

}
