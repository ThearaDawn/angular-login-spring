export const URL_BACKEND = 'http://localhost:8080/';
